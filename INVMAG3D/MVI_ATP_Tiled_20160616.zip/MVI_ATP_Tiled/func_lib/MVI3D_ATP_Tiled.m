function [M] = MVI3D_ATP_Tiled(work_dir,out_dir,dsep,tile_id,xn,yn,zn,H, HI, HD, obsx, obsy, obsz, G, d, wd,mstart,mref,chi_target,alphas,beta,bounds,LP,t,eps_FLAG,eps_tresh,FLAG1,FLAG2,max_iter,ROT)
% Magnetic Vector Inversion in spherical coordinates 
% Written by: D Fournier 
% Last update: 2016/05/01


% Load mesh file and convert to vectors (UBC format)
dx = xn(2:end) - xn(1:end-1); nx = length(dx);
dy = yn(2:end) - yn(1:end-1); ny = length(dy);
dz = zn(1:end-1) - zn(2:end); nz = length(dz);

mcell = nx*ny*nz;


ndata = length(d);
            
Wd = spdiags(1./wd,0,ndata,ndata);

d = Wd * d;

switcher = 0;

for pst = 1 : 3
    if eps_FLAG == 1
        eps_q(pst) = eps_tresh(2);
        eps_p(pst) = eps_tresh(1);

    else

        eps_q(pst) = 1e-2;
        eps_p(pst) = 1e-2;
    end
end

%% Create model magnetization vectors
% Need to create I/O for cell base weights
w = ones(4*mcell,1);

% Create bound vector
lowBvec = [ones(mcell,1) * bounds(1,1);ones(mcell,1) * bounds(2,1);ones(mcell,1) * bounds(3,1)];
uppBvec = [ones(mcell,1) * bounds(1,2);ones(mcell,1) * bounds(2,2);ones(mcell,1) * bounds(3,2)];

%% Initialize dynamic cells
% Create selector matrix for active cells
load([work_dir dsep 'nullcell.dat']);
x = spdiags(nullcell,0,mcell,mcell);
x = x(nullcell==1,:);
X = kron(speye(3),x);

mactv = sum(nullcell);

lowBvec = X * lowBvec;
uppBvec = X * uppBvec;

t = x*t;

%% Load forward operator
% TMI = [(cosd(I) * cosd(D)) (cosd(I) * sind(D)) sind(I)];
fprintf('Loading Sensitivity...\n');

% Case sperical
m_uvw = @(a,t,p) [a.*cos(pi*t).*cos(pi*p);...
    a.*cos(pi*t).*sin(pi*p);...
    a.*sin(pi*t)];

sProj = @(a,theta,phi)[spdiags(cos(pi*theta).*cos(pi*phi),0,mactv,mactv) spdiags(-a.*sin(pi*theta).*cos(pi*phi)*pi,0,mactv,mactv) spdiags(-a.*cos(pi*theta).*sin(pi*phi)*pi,0,mactv,mactv);
    spdiags(cos(pi*theta).*sin(pi*phi),0,mactv,mactv) spdiags(-a.*sin(pi*theta).*sin(pi*phi)*pi,0,mactv,mactv) spdiags(a.*cos(pi*theta).*cos(pi*phi)*pi,0,mactv,mactv);
    spdiags(sin(pi*theta),0,mactv,mactv) spdiags(a.*cos(pi*theta)*pi,0,mactv,mactv) sparse(mactv,mactv)];

%% Create gradient matrices and corresponding volume vectors
[A, GRAD, ~] = get_GRAD_op3D_TENSIL_Kron(dx,dy,dz,nullcell,'FWR');
% [Ws, V ] = getWs3D(dx,dy,dz,X);

Ws =  spdiags(x * ( w(1:mcell)  )  ,0,mactv,mactv);
Wx =  spdiags(x * ( w(1+mcell:2*mcell) )  ,0,mactv,mactv);
Wy =  spdiags(x * ( w(1+2*mcell:3*mcell) )  ,0,mactv,mactv);
Wz =  spdiags(x * ( w(1+3*mcell:4*mcell) )  ,0,mactv,mactv);

%% Rotate gradient operators

Rz = @(x)   [cosd(x) -sind(x) 0;
            sind(x) cosd(x) 0;
            0 0 1];

Ry = @(x)   [cosd(x) 0 -sind(x);
            0 1 0;
            sind(x) 0 cosd(x)];

Rx = @(x)   [1 0 0;
            0 cosd(x) -sind(x);
            0 sind(x) cosd(x)];
        
rz = Rz(ROT(1));
%     rz = rz*spdiags(sum(abs(rz),2).^-1,0,3,3);

ry = Ry(ROT(2));
%     ry = ry*spdiags(sum(abs(ry),2).^-1,0,3,3);

rx = Rx(ROT(3));

rot = rx*ry*rz;
% Scale the rows


% Get index and weight for gradients Gx
[val,ind] = sort(45 - acosd(A*rot(1,:)'),'descend') ;

Gx = GRAD{ind(1)} * val(1);
denom = val(1);
count = 2;
while round(denom) < (45 )
    
    Gx = Gx + GRAD{ind(count)} * val(count);
    denom = denom + val(count);
    count = count + 1;
    
end

Gx = Gx * spdiags(ones(mactv,1)/denom,0,mactv,mactv);
% indx = round(sum(abs(Gx),2)) ~= 2;
% Gx(indx,:) = 0;

% Get index and weight for gradients Gx
[val,ind] = sort(45 - acosd(A*rot(2,:)'),'descend') ;

Gy = GRAD{ind(1)} * val(1);
denom = val(1);
count = 2;
while round(denom) < (45 )
    
    Gy = Gy + GRAD{ind(count)} * val(count);
    denom = denom + val(count);
    count = count + 1;
    
end

Gy = Gy * spdiags(ones(mactv,1)/denom,0,mactv,mactv);
% indx = round(sum(abs(Gy),2)) ~= 2;
% Gy(indx,:) = 0;


% Get index and weight for gradients Gx
[val,ind] = sort(45 - acosd(A*rot(3,:)'),'descend') ;

Gz = GRAD{ind(1)} * val(1);
denom = val(1);
count = 2;
while round(denom) < (45)
    
    Gz = Gz + GRAD{ind(count)} * val(count);
    denom = denom + val(count);
    count = count + 1;
    
end

Gz = Gz * spdiags(ones(mactv,1)/denom,0,mactv,mactv);



%% START INVERSION
mactv = sum(nullcell);
target = chi_target * ndata;     % Target misifit
invmod      =  X*mstart ;
mref = X*mref;

aa = invmod(1:mactv);
tt = invmod(1+mactv:2*mactv);
pp = invmod(1+2*mactv:3*mactv);



% phi_init    = sum((G * invmod - d).^2);   % Initial misfit
phi_d       = sum(((Gvec(G,Wd,m_uvw(aa,tt,pp)) - d) ).^2);
% phi_m       =    (invmod-mref)'* ( aVRWs'*aVRWs * (invmod-mref) ) +...
%                   (invmod)'*( aVRWx'*aVRWx * (invmod) ) +...
%                   (invmod)'*( aVRWy'*aVRWy * (invmod) ) +...
%                   (invmod)'*( aVRWz'*aVRWz * (invmod) ) ;  
% phi         = phi_d  + beta*phi_m;

% Initiate active cell
Pac = speye(3*mactv);

% Message prompt
logfile = [work_dir dsep 'Log_TMVI.log'];
fid = fopen(logfile,'w');
fprintf(fid,'Starting lp inversion\n');
fprintf(fid,'Starting misfit %e\n',phi_d);
fprintf(fid,'Target misfit %e\n',target);
fprintf(fid,'Iteration:\t\tBeta\t\tphid\t\tphis\t\t ');
fprintf(fid,'phix\t\tphiy\t\tphiz\t\tphim\t\tphi\t\t ');
fprintf(fid,'#cut cells \t # CG Iter\n');

count= 0; % Initiate iteration count 
tncg = 0; % Compute total number of CG iterations for the whole inversion
lp_count = 0;

% Switcher defines the different modes of the inversion
% switcher 0: Run the usual l2-l2 inversion, beta decreases by 2
% switcher 1: Run the lp-lq inversion, beta decreases by 0.8
% swircher 2: End on inversion - model update < treshold
% if phid_in < target
%     
%     switcher = 1; 
%     
% else
%     
%     switcher = 0; 
%     
% end
alphas = kron(alphas,ones(3,1));
alphas(2:3,1) = 0;
dphim = 100;
scl_t = 1;
scl_p = 1;
while switcher ~= 3 && count ~= max_iter

    fprintf(['MVI: Tile' num2str(tile_id) '\n'])
    count=count+1;

    if switcher == 0 %count == 1   

        delta_p(1:3) = 1e-1;%delta_tresh(1)*3;
        delta_q(1:3) = 1e-1;%delta_tresh(2)*3;


        aa = invmod(1:mactv);
        tt = invmod(1+mactv:2*mactv);
        pp = invmod(1+2*mactv:3*mactv);

%         J   =  ;
        S = sProj(aa,tt,pp);

        [aVRWs,aVRWx,aVRWy,aVRWz] = get_lp_MOF_3D_noGamma(invmod,mref,1,Ws,Wx,Wy,Wz,Gx,Gy,Gz,t,alphas,kron([1 1 1],[2 2 2 2 1]),FLAG1,FLAG2,switcher,delta_p,delta_q);

        wr = zeros(1,3*mactv);
        for gg = 1 : ndata
            wr = wr +  ( (G{1}(gg,:)* S)).^2;
        end   

%         % Re-weighted pseudo sensitivity weighting for each component
        wr = abs(sqrt(wr+1e-8))';
        
        wr = wr / max(wr);

        
        phi_a = (invmod(1:mactv))'*(Ws'*spdiags(wr(1:mactv),0,mactv,mactv)*Ws)*(invmod(1:mactv)) + invmod(1:mactv)'*(Gx'*Wx'*spdiags(wr(1:mactv),0,mactv,mactv)*Wx*Gx + Gy'*Wy'*spdiags(wr(1:mactv),0,mactv,mactv)*Wy*Gy + Gz'*Wz'*spdiags(wr(1:mactv),0,mactv,mactv)*Wz*Gz)*invmod(1:mactv);
        phi_tp = invmod(1+mactv:2*mactv)'*(Gx'*Wx'*spdiags(wr(1+mactv:2*mactv),0,mactv,mactv)*Wx*Gx + Gy'*Wy'*spdiags(wr(1+mactv:2*mactv),0,mactv,mactv)*Wy*Gy + Gz'*Wz'*spdiags(wr(1+mactv:2*mactv),0,mactv,mactv)*Wz*Gz)*invmod(1+mactv:2*mactv)+...
                 invmod(1+2*mactv:3*mactv)'*(Gx'*Wx'*spdiags(wr(1+2*mactv:3*mactv),0,mactv,mactv)*Wx*Gx + Gy'*Wy'*spdiags(wr(1+2*mactv:3*mactv),0,mactv,mactv)*Wy*Gy + Gz'*Wz'*spdiags(wr(1+2*mactv:3*mactv),0,mactv,mactv)*Wz*Gz)*invmod(1+2*mactv:3*mactv);

        scl = (phi_a/phi_tp)/2;

        wr(1:mactv)= wr(1:mactv);
        wr(1+mactv:2*mactv)= wr(1+mactv:2*mactv)*scl;%/(max(wr(1:mcell))/max(wr(1+mcell:2*mcell))) ;
        wr(1+2*mactv:3*mactv)= wr(1+2*mactv:3*mactv)*scl/2;%/(max(wr(1:mcell))/max(wr(1+2*mcell:3*mcell)));

        Wr = spdiags(wr,0,3*mactv,3*mactv);

        mof = aVRWs'*Wr*aVRWs + aVRWx'*Wr*aVRWx + aVRWy'*Wr*aVRWy + aVRWz'*Wr*aVRWz;

        % Estimate beta if not provided
        if isempty(beta)==1

            temp = randn(3*mactv,1);
            temp = temp/max(temp)*.5;
            beta = sum(((Gvec(G,Wd,temp))).^2) / (temp'*mof*temp) * 1e+2 ;

        end


        phi_MOF = (invmod-mref)'* ( aVRWs'*Wr*aVRWs * (invmod-mref) ) +...
              (invmod)'*( aVRWx'*Wr*aVRWx * (invmod) ) +...
              (invmod)'*( aVRWy'*Wr*aVRWy * (invmod) ) +...
              (invmod)'*( aVRWz'*Wr*aVRWz * (invmod) ) ;

        phi(count) = norm((Gvec(G,Wd,m_uvw(aa,tt,pp)) - d)).^2 + beta(count) + phi_MOF;
%         tresh = dkdt(2,delta(count));


    else

        lp_count = lp_count+1;

        if lp_count == 1 

            if eps_FLAG==0 

                Z = zeros(1,3);
                Z(1) = 1;

                % Create sub-space matrix and grab the right model
                Z = kron(Z,speye(mactv));
                m = Z*(invmod-mref);

                [pp,qq] = get_eps(m,10,Gx,Gy,Gz);

                delta_p(1) = pp;
                delta_q(1) = qq;

            else

                delta_p(1) = eps_p(pst);
                delta_q(1) = eps_q(pst);

            end

            delta_p(2:3) = delta_p(1); % Doesn't matter since not active
            delta_q(2:3) = 1.5e-1; % Fix value since always angles

            aa = invmod(1:mactv);
            tt = invmod(1+mactv:2*mactv);
            pp = invmod(1+2*mactv:3*mactv);

            model_out = X'*(m_uvw(aa,tt,pp));

            M = reshape(model_out,mcell,3);
            Mamp = sum(M.^2,2).^0.5;
            Mamp(nullcell==0) = -100;

            pred_TMI = Gvec(G,speye(ndata),m_uvw(aa,tt,pp));
            write_MAG3D_TMI([work_dir dsep 'Tile' num2str(tile_id) '_l2l2_MVI.pre'],H,HI,HD,HI,HD,obsx,obsy,obsz,pred_TMI,wd);
            save([work_dir dsep 'Tile' num2str(tile_id) '_l2l2_MVI.fld'],'-ascii','M')
            save([work_dir dsep 'Tile' num2str(tile_id) '_l2l2_MVI.amp'],'-ascii','Mamp')

            figure;
            subplot(1,3,1)
            temp = invmod(1:mactv) - mref(1:mactv);
            [n, xout] =hist((temp),100); hold off
            bar(xout,n);  
            set(gca,'yscale','log')
            title('L2 amp values')

            subplot(1,3,2)
            [n, xout] =hist((Gx * invmod(1+mactv:2*mactv)),100); hold off
            bar(xout,n);  
            set(gca,'yscale','log')
            title('L2 \Delta \theta values')

            subplot(1,3,3)
            [n, xout] =hist((Gx * invmod(1+2*mactv:3*mactv)),100); hold off
            bar(xout,n);  
            set(gca,'yscale','log')
            title('L2 \Delta \phi values')


        end

        if dphim(end)  < 1 && lp_count > 1 && phi_d(count-1) < target * (1+0.25) && phi_d(count-1) > target * (1-0.25)%traffic_s(end)*100 <= 1  && traffic_xyz(end)*100 <= 1

            fprintf('\n# # ADJUST BETA # #\n');
            switcher = 2;

        else

            fprintf('\n# # LP-LQ ITER# #\n');

        end

        %% Update the regularization
        fprintf('# # LP-LQ ITER# #\n');
        [aVRWs,aVRWx,aVRWy,aVRWz] = get_lp_MOF_3D_noGamma(invmod,mref,phi_m(end),Ws,Wx,Wy,Wz,Gx,Gy,Gz,t,alphas,LP,FLAG1,FLAG2,switcher,delta_p,delta_q);

    end

    %% Gauss-Newton steps

    fprintf('\n# # # # # # # # #\n');
    fprintf('BETA ITER: \t %i  \nbeta: \t %8.5e \n',count,beta(count));
    str_var = ['A','T','P'];
    for pst = 1 : 3
        fprintf([str_var(pst) 'eps_p: \t %8.5e \t eps_p*: \t %8.5e\n'],delta_p(pst),eps_p(pst))
        fprintf([str_var(pst) 'eps_q: \t %8.5e \t eps_q*: \t %8.5e\n'],delta_q(pst),eps_q(pst))
    end

    % Save current model
    m_in = invmod;

    tncg = 0;
    ggdm = 1;       % Mesure the relative change in rel|dm|
    ddm = [1 1];    % Mesure of change in model update |dm|
    solves = 1;

    phi_d(count) = sum(( Gvec(G,Wd,m_uvw(aa,tt,pp)) - d ).^2);

    if switcher ~=0
        temp = (invmod-mref);
%                 temp(1+mactv:2*mactv) = sin(pi*2*temp(1+mactv:2*mactv));
%                 temp(1+2*mactv:3*mactv) = sin(pi*temp(1+2*mactv:3*mactv)); 
        
        gamma = phi_m(end) /(...
                    (temp)'* ( aVRWs'*Wr*aVRWs * (temp) ) +...
                    (( (aVRWx * invmod) )' * Wr * ( aVRWx * invmod ))+...
                    (( (aVRWy * invmod) )' * Wr *( aVRWy * invmod ))+...
                    (( (aVRWz * invmod) )' * Wr *( aVRWz * invmod )));
                % gamma=1;
            aVRWs = sqrt(gamma) * aVRWs; 
            aVRWx = sqrt(gamma) * aVRWx;
            aVRWy = sqrt(gamma) * aVRWy;
            aVRWz = sqrt(gamma) * aVRWz;
    end
    
    temp = (invmod-mref);
                
    phi_MOF = (temp)'* ( aVRWs'*Wr*aVRWs * (temp) ) +...
                      (invmod)'*( aVRWx'*Wr*aVRWx * (invmod) ) +...
                      (invmod)'*( aVRWy'*Wr*aVRWy * (invmod) ) +...
                      (invmod)'*( aVRWz'*Wr*aVRWz * (invmod) ) ;
                  
    phi_in = phi_d(count) + beta(count) * phi_MOF;

                        % Try scaling the transformation matrix
    solves_max= 5;

    while solves <= solves_max %&& ggdm > 1e-2
        aa = invmod(1:mactv);
        tt = invmod(1+mactv:2*mactv);
        pp = invmod(1+2*mactv:3*mactv);

        S = sProj(aa,tt,pp);
        wr = zeros(1,3*mactv);
        for gg = 1 : ndata
            wr = wr +  ( (G{1}(gg,:)* S)).^2;
        end
        
        wr = abs(sqrt(wr+1e-8))';

        
        wr = wr / max(wr);
        
        if switcher == 0
            phi_a = (invmod(1:mactv)-mref(1:mactv))'*(Ws'*spdiags(wr(1:mactv),0,mactv,mactv)*Ws)*(invmod(1:mactv)-mref(1:mactv)) + invmod(1:mactv)'*(Gx'*Wx'*spdiags(wr(1:mactv),0,mactv,mactv)*Wx*Gx + Gy'*Wy'*spdiags(wr(1:mactv),0,mactv,mactv)*Wy*Gy + Gz'*Wz'*spdiags(wr(1:mactv),0,mactv,mactv)*Wz*Gz)*invmod(1:mactv);
            phi_tp = invmod(1+mactv:2*mactv)'*(Gx'*Wx'*spdiags(wr(1+mactv:2*mactv),0,mactv,mactv)*Wx*Gx + Gy'*Wy'*spdiags(wr(1+mactv:2*mactv),0,mactv,mactv)*Wy*Gy + Gz'*Wz'*spdiags(wr(1+mactv:2*mactv),0,mactv,mactv)*Wz*Gz)*invmod(1+mactv:2*mactv)+...
                    invmod(1+2*mactv:3*mactv)'*(Gx'*Wx'*spdiags(wr(1+2*mactv:3*mactv),0,mactv,mactv)*Wx*Gx + Gy'*Wy'*spdiags(wr(1+2*mactv:3*mactv),0,mactv,mactv)*Wy*Gy + Gz'*Wz'*spdiags(wr(1+2*mactv:3*mactv),0,mactv,mactv)*Wz*Gz)*invmod(1+2*mactv:3*mactv);

            scl = (phi_a/phi_tp)/2;
       
            fprintf('Scale t: %f\t',scl)

        end

        wr(1:mactv)= wr(1:mactv);
        wr(1+mactv:2*mactv)= wr(1+mactv:2*mactv)*scl;%/(max(wr(1:mcell))/max(wr(1+mcell:2*mcell))) ;
        wr(1+2*mactv:3*mactv)= wr(1+2*mactv:3*mactv)*scl;%/(max(wr(1:mcell))/max(wr(1+2*mcell:3*mcell)));

        Wr = spdiags(wr,0,3*mactv,3*mactv);

        mof = aVRWs'*Wr*aVRWs + aVRWx'*Wr*aVRWx + aVRWy'*Wr*aVRWy + aVRWz'*Wr*aVRWz;

        diagJ = zeros(1,3*mactv);
        for gg = 1 : ndata
            diagJ = diagJ +  ( G{1}(gg,:)* S).^2;
        end

        diagA   = diagJ + beta(count)*spdiags( mof ,0)';
        PreC    = Pac * spdiags(1./diagA(:),0,3*mactv,3*mactv);

        switch FLAG1

            case 'SMOOTH_MOD'
                
                temp = (invmod-mref);
                
                g_MOF = ( aVRWs'*Wr*aVRWs * temp ) +...
                        ( aVRWx'*Wr*aVRWx * (invmod) ) +...
                        ( aVRWy'*Wr*aVRWy * (invmod) ) +...
                        ( aVRWz'*Wr*aVRWz * (invmod) );

                g = - S'*(Gtvec(G,Wd,(Gvec(G,Wd,m_uvw(aa,tt,pp)) - d))) - beta(count)*g_MOF;

            case 'SMOOTH_MOD_DIF'
                
                fprintf('SMOOTH_MOD_DIF NOT IMPLEMENTED...SORRY!\n')
    %                 g = [- (magB - d) ; ...
    %             - sqrt( beta(count) ) * ( aVRWs * (invmod-mref) ) ;...
    %             - sqrt( beta(count) ) * ( aVRWx * (invmod-mref) ) ;...
    %             - sqrt( beta(count) ) * ( aVRWy * (invmod-mref) ) ;...
    %             - sqrt( beta(count) ) * ( aVRWz * (invmod-mref) ) ];
        end 


        %% Projected steepest descent
        dm =zeros(3*mactv,1);
        [dm,~,ncg] = CG_Lin( dm, G, Wd, beta(count) * mof , g, S, PreC, Pac );

        %% TESTING 
%         if max(abs(dm(1+mactv:2*mactv))) > max(abs(bounds(2,:)))
%             dm(1+mactv:2*mactv) = dm(1+mactv:2*mactv)/10;
%         end
%         
%         if max(abs(dm(1+2*mactv:3*mactv))) > max(abs(bounds(3,:)))
%             dm(1+2*mactv:3*mactv) = dm(1+2*mactv:3*mactv)/10;
%         end

        %% Step length, line search                
        tncg = tncg+ncg; % Record the number of CG iterations

        temp = spdiags(Pac);
        phi_out = phi_in;
        phi_temp = phi_in;
        m_temp = invmod;
        % Combine active and inactive cells step if active bounds
        if sum(temp)~=3*mactv

            for dd = 1 : 3
%                 
                k = zeros(3,3);
                k(dd,dd) = 1;
%                 
%     % Create sub-space matrix and grab the right model
            K = kron(k,speye(mactv));
            
            rhs_a = K*( speye(3*mactv) - Pac ) * (g);
                        
            dm_i = max( abs( K*dm ) );
            dm_a = max( abs(rhs_a) ); 
                        if dm_i < dm_a
                            dm = dm + rhs_a * dm_i / dm_a * 1e-8 ;
                        else
                            dm = dm + rhs_a;
                        end
            end
            
        end
        gamma = 2;

        % Reduce step length in order to reduce phid
        count_LS = 0;
        while (phi_out >= phi_in) && count_LS < 5
            count_LS = count_LS+1;
%             phi_temp(2) = phi_temp(1);
            if phi_temp < phi_out
                gamma = 0.5 * gamma;
            else
                gamma = 0.5 * gamma;
            end
            

            gdm = gamma * dm;

            ddm(2) = norm(gdm);
            
            m_temp = invmod + gdm;

            lowb = m_temp <= lowBvec;
            uppb = m_temp >= uppBvec;

            % Apply bound on model
            m_temp(lowb==1) = lowBvec(lowb==1);
            m_temp(uppb==1) = uppBvec(uppb==1);

            % Update projection matrix
            Pac = spdiags((lowb==0).*(uppb==0),0,3*mactv,3*mactv);

            aa = m_temp(1:mactv);
            tt = m_temp(1+mactv:2*mactv);
            pp = m_temp(1+2*mactv:3*mactv);

            temp = (m_temp-mref);
            
            phi_MOF = (temp)'* ( aVRWs'*Wr*aVRWs * (temp) ) +...
                      (m_temp)'*( aVRWx'*Wr*aVRWx * (m_temp) ) +...
                      (m_temp)'*( aVRWy'*Wr*aVRWy * (m_temp) ) +...
                      (m_temp)'*( aVRWz'*Wr*aVRWz * (m_temp) ) ;

            phi_temp = phi_out;
            phi_out = sum((Gvec(G,Wd,m_uvw(aa,tt,pp)) - d).^2) + beta(count) * phi_MOF;

        end

        phi_in = phi_out;

        if solves == 1

            ggdm = 1;
            ddm(1) = ddm(2);

        else

            ggdm = ddm(2)/ddm(1);

        end


        % Update model
        invmod = m_temp;
%         phi_m(count) = phi_MOF;
%         fprintf('GN iter %i |g| rel:\t\t %8.5e\n',solves,ggdm);
        fprintf('GN iter %i: , Step Length: %f, phi_m :\t\t %8.5e\n',solves,ddm(2),phi_MOF);
        solves = solves + 1;


    end
    %% Save iteration and continue
    % Measure the update length
    if count==1 

        rdm(count) =  1;
        gdm(1) = norm(m_in - invmod);

    else

        gdm(2) = norm(m_in - invmod);
        rdm(count) = abs( gdm(2) - gdm(1) ) / norm(invmod);

        gdm(1) = gdm(2);

    end

    aa = invmod(1:mactv);
    tt = invmod(1+mactv:2*mactv);
    pp = invmod(1+2*mactv:3*mactv);

    phi_d(count) = sum(( Gvec(G,Wd,m_uvw(aa,tt,pp)) - d ).^2);

    temp = (invmod-mref);
                
    phi_MOF = (temp)'* ( aVRWs'*Wr*aVRWs * (temp) ) +...
                      (invmod)'*( aVRWx'*Wr*aVRWx * (invmod) ) +...
                      (invmod)'*( aVRWy'*Wr*aVRWy * (invmod) ) +...
                      (invmod)'*( aVRWz'*Wr*aVRWz * (invmod) ) ;
                  
    phi_m(count) = phi_MOF;

    phi(count) = phi_d(count) + beta(count) * phi_MOF;

    if count ~= 1

        dphim(count) = abs(phi_m(count) - phi_m(count-1)) / phi_m(count) *100;

    end

    % Get truncated cells
    tcells = spdiags(Pac);


%     fprintf('---------->\n')
    fprintf(' phi_d:\t %8.5e \n',phi_d(count))
    fprintf(' phi_m:\t %8.5e \n',phi_m(count))
    fprintf(' dphi_m:\t %8.5e \n',dphim(count))
%     fprintf('Final Relative dm:\t %8.5e \n', rdm(count));
%     fprintf('<----------\n')
%     
%     fprintf('Number of Inactive cells: %i\n',sum(tcells));
%     fprintf('Number of CGS iterations: %i\n\n',ncg);

    % Get next beta
    [switcher,beta(count+1)] = cool_beta(beta(count),phi_d(count),dphim(count),target,switcher,0.25,2);


    % Write log file
    fprintf(fid,' \t %i \t %8.5e ',count,beta(count));
    fprintf(fid,' \t %8.5e ',phi_d(count));
    fprintf(fid,' \t %8.5e ',sum( (aVRWs*invmod).^2 ) );
    fprintf(fid,' \t %8.5e ',sum( (aVRWx*invmod).^2 ));
    fprintf(fid,' \t %8.5e ',sum( (aVRWy*invmod).^2 ));
    fprintf(fid,' \t %8.5e ',sum( (aVRWz*invmod).^2 ));
    fprintf(fid,' \t %8.5e ',phi_MOF);
    fprintf(fid,' \t %8.5e ',phi(count));
    fprintf(fid,' \t\t %i ',sum(tcells));
    fprintf(fid,' \t\t %i\n',ncg);

%%
    aa = invmod(1:mactv);
    tt = invmod(1+mactv:2*mactv);
    pp = invmod(1+2*mactv:3*mactv);
        
    model_out = X'*(m_uvw(aa,tt,pp));
    M = reshape(model_out,mcell,3);
    Mamp = sum(M.^2,2).^0.5;
    Mamp(nullcell==0) = -100;


    pred_TMI = Gvec(G,speye(ndata),m_uvw(aa,tt,pp));
    write_MAG3D_TMI([work_dir dsep 'Tile' num2str(tile_id) '_MVI.pre'],H,HI,HD,HI,HD,obsx,obsy,obsz,pred_TMI,wd);
    save([work_dir dsep 'Tile' num2str(tile_id) '_MVI.fld'],'-ascii','M')
    save([work_dir dsep 'Tile' num2str(tile_id) '_MVI.amp'],'-ascii','Mamp')
%     write_MAG3D_TMI([work_dir dsep 'Tile' num2str(idx) '_iter_' num2str(count) '.pre'],H,I,Dazm,obsx,obsy,obsz,(G*invmod).*wd,wd);
end

figure;
subplot(1,3,1)
temp = invmod(1:mactv) - mref(1:mactv);
[n, xout] =hist((temp),100); hold off
bar(xout,n);  
set(gca,'yscale','log')
title('Final amp values')

subplot(1,3,2)
[n, xout] =hist((Gx * invmod(1+mactv:2*mactv)),100); hold off
bar(xout,n);  
set(gca,'yscale','log')
title('Final \Delta \theta values')

subplot(1,3,3)
[n, xout] =hist((Gx * invmod(1+2*mactv:3*mactv)),100); hold off
bar(xout,n);  
set(gca,'yscale','log')
title('Final \Delta \phi values')
write_MAG3D_TMI([out_dir dsep 'Tile' num2str(tile_id) '_MVI.pre'],H,HI,HD,HI,HD,obsx,obsy,obsz,pred_TMI,wd);

